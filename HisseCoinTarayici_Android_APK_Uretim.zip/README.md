# Hisse&Coin Tarayıcı
Telefonla APK üretmek için Android projesi.

GitHub'da yeni repo oluşturup bu dosyaları yükle.
Actions > Build Android APK > Run workflow.
İşlem bitince Artifacts bölümünden HisseCoinTarayici-debug-apk dosyasını indir ve APK'yı telefona kur.
