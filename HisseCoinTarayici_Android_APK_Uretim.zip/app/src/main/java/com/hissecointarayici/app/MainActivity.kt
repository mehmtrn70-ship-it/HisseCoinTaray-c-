package com.hissecointarayici.app
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,28,28,28)}
        box.addView(TextView(this).apply{text="Hisse&Coin Tarayıcı";textSize=27f})
        box.addView(TextView(this).apply{text="BIST + Kripto | Teknik tarama | Otomatik işlem yok"})
        val key=EditText(this).apply{hint="Veri API anahtarı"}
        box.addView(key)
        val syms=EditText(this).apply{hint="THYAO:BIST, ASELS:BIST, BTC/USD";setText("THYAO:BIST, ASELS:BIST, TUPRS:BIST, BTC/USD, ETH/USD")}
        box.addView(syms)
        val btn=Button(this).apply{text="TARAMAYI BAŞLAT"}; box.addView(btn)
        val out=TextView(this).apply{setPadding(0,18,0,0)}; box.addView(out)
        btn.setOnClickListener{
            if(key.text.toString().trim().isEmpty()){out.text="API anahtarı gerekli.";return@setOnClickListener}
            val s=syms.text.toString().split(",").map{it.trim()}.filter{it.isNotEmpty()}
            out.text="Tarama listesi hazır: ${s.joinToString(", ")}"
        }
        setContentView(box)
    }
}
